#include "myapp.h"
#include "ICETEK-VC5509-EDU.h"
#include "scancode.h"

// ���� Sobel ��ص��ⲿ�����ͺ���
#define IMAGEWIDTH 80
#define IMAGEHEIGHT 80
extern unsigned char dbImage[IMAGEWIDTH*IMAGEHEIGHT];
extern unsigned char dbTargetImage[IMAGEWIDTH*IMAGEHEIGHT];
void InitImage(unsigned int nMode, unsigned char *pImage, int nWidth, int nHeight);
void Sobel(int nWidth, int nHeight);

#define MODEGRAYBAR 0
#define MODEGRAY 1

main()
{
    int dbScanCode;
    int nCurrentMode = 0;

    PLL_Init(20);
    SDRAM_init();
    InitCTR();

    for (;;)
    {
        dbScanCode = GetKey();
        dbScanCode &= 0x0ff;

        if(dbScanCode == SCANCODE_9)  
            break;

        // ���� '1' -> �Ҷ��� + Sobel
        if (dbScanCode == 1)
        {
            nCurrentMode = MODEGRAYBAR;
            InitImage(nCurrentMode, dbImage, IMAGEWIDTH, IMAGEHEIGHT);
            Sobel(IMAGEWIDTH, IMAGEHEIGHT);
            
            // ��ʱԼ 5 �루�ɵ�����ֵ�����Ա�۲�ͼ�Σ�֮���Զ�������ѭ��
            Delay(5000);
        }
        else if (dbScanCode == 2)   // ���� '2' -> ����Բ + Sobel
        {
            nCurrentMode = MODEGRAY;
            InitImage(nCurrentMode, dbImage, IMAGEWIDTH, IMAGEHEIGHT);
            Sobel(IMAGEWIDTH, IMAGEHEIGHT);
            
            Delay(5000);
        }
        else  // ������������ LED������ԭ���ܣ�
        {
            switch(dbScanCode)
            {
                case 3: CTRLR=0x4; CTRLR=0x40; break;
                case 4: CTRLR=0x0; CTRLR=0x48; break;
                case 5: CTRLR=0x0; CTRLR=0x50; break;
                case 6: CTRLR=0x0; CTRLR=0x60; break;
                case 7: CTRLR=0x8; CTRLR=0x40; break;
                case 8: CTRLR=0x10; CTRLR=0x40; break;
                default: break;
            }
        }
        Delay(16);
    }
    CloseCTR();
    exit(0);
}