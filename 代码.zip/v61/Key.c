#include <stdlib.h>
#include "myapp.h"
#include "ICETEK-VC5509-EDU.h"
#include "dsp_app.h"

int main(void)
{
    int dbScanCode;
    PLL_Init(20);
    SDRAM_init();
    InitCTR();
    app_init();
    for (;;) {
        dbScanCode=GetKey();
        dbScanCode &= 0x0ff;
        if (dbScanCode==9) { gLastKey=9; gStopped=1; break; }
        if (dbScanCode>=1 && dbScanCode<=8) {
            app_handle_key((unsigned int)dbScanCode);
            /* Optional CCS breakpoint on this line: result is complete. */
            Delay(16);
        }
        Delay(16);
    }
    CloseCTR();
    return 0;
}
