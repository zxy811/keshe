#include "dsp_app.h"
#include "ImageData.h"

void app_load_source(void)
{
    unsigned int n;
    /* sample.bmp has already been embedded in ImageData.h.
       No target fopen, PC path, data import, or Python is required. */
    for (n=0;n<IMAGEPIXELS;++n) dbImage[n]=gFixedImage[n];
}
