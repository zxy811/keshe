#include "dsp_app.h"
extern const dsp_i16 gTestSignal[FFT_N],gMessageSignal[FFT_N];

static dsp_i16 magnitude(dsp_i16 re,dsp_i16 im)
{
    unsigned long op,result,bit;
    dsp_i32 r,i;
    r=re; i=im;
    op=(unsigned long)(r*r)+(unsigned long)(i*i);result=0;bit=1UL<<30;
    while (bit>op) bit >>= 2;
    while (bit!=0) {
        if (op>=result+bit) {
            op-=result+bit;result=(result>>1)+bit;
        } else result >>= 1;
        bit >>= 2;
    }
    if (result>32767UL) result=32767UL;
    return (dsp_i16)result;
}

static void render_spectrum(void)
{
    int x,y,bin,first,last,height;
    dsp_i32 top,mag;
    top=1;
    for (bin=0;bin<=FFT_N/2;++bin) {
        gFFTMag[bin]=magnitude(gFFTReal[bin],gFFTImag[bin]);
        if (gFFTMag[bin]>top) top=gFFTMag[bin];
    }
    for (x=0;x<IMAGEWIDTH;++x) {
        first=x*(FFT_N/2+1)/IMAGEWIDTH;
        last=(x+1)*(FFT_N/2+1)/IMAGEWIDTH;
        mag=0;
        for (bin=first;bin<last;++bin)
            if (gFFTMag[bin]>mag) mag=gFFTMag[bin];
        height=(int)(mag*(IMAGEHEIGHT-1L)/top);
        for (y=0;y<IMAGEHEIGHT;++y)
            dbTargetImage[y*IMAGEWIDTH+x]=(unsigned char)
                ((IMAGEHEIGHT-1-y<=height)?240:10);
    }
}

void App_ResultReady(void) { gBusy=0; }

void app_init(void)
{
    int n;
    gBusy=0;gResultSeq=0;gMode=MODE_LPF;gCutoffIndex=3;
    gLastKey=0;gFilterIndex=3;gStopped=0;
    for (n=0;n<FFT_N;++n) {gFFTReal[n]=0;gFFTImag[n]=0;}
    for (n=0;n<=FFT_N/2;++n) gFFTMag[n]=0;
    app_process();
}

void app_process(void)
{
    int n;
    gBusy=1;
    app_load_source();
    for (n=0;n<FFT_N;++n) {
        gSignalIn[n]=(gMode>=MODE_AM)?gMessageSignal[n]:gTestSignal[n];
        gSignalOut[n]=0;
    }
    if (gMode>=MODE_LPF && gMode<=MODE_BRF) {
        if (gMode==MODE_LPF) gFilterIndex=gCutoffIndex;
        else gFilterIndex=(gMode==MODE_BPF?10:19)+gCutoffIndex%9;
        app_filter_image(gFilterIndex);
        app_filter_signal(gFilterIndex);
    } else if (gMode==MODE_FFT_C || gMode==MODE_FFT_DIF) {
        for (n=0;n<FFT_N;++n) {
            gFFTReal[n]=(n<IMAGEWIDTH)?
                (dsp_i16)(((int)dbImage[40*IMAGEWIDTH+n]-128)*128):0;
            gFFTImag[n]=0;
        }
        if (gMode==MODE_FFT_C) fft_c(gFFTReal,gFFTImag);
        else fft_dif(gFFTReal,gFFTImag);
        render_spectrum();
    } else app_modulate(gMode==MODE_DSB);
    for (n=0;n<IMAGEWIDTH;++n) {
        gInputRow[n]=(dsp_i16)dbImage[40*IMAGEWIDTH+n];
        gOutputRow[n]=(dsp_i16)dbTargetImage[40*IMAGEWIDTH+n];
    }
    gResultSeq=(gResultSeq+1U)&65535U;
    App_ResultReady();
}

void app_handle_key(unsigned int key)
{
    if (gStopped) return;
    gLastKey=key;
    if (key==9) {gStopped=1;return;}
    if (key>=1 && key<=7) {
        gMode=key;
        if (key==MODE_BPF || key==MODE_BRF) gCutoffIndex%=9U;
    } else if (key==8) {
        if (gMode==MODE_BPF || gMode==MODE_BRF)
            gCutoffIndex=(gCutoffIndex+1U)%9U;
        else gCutoffIndex=(gCutoffIndex+1U)%10U;
    } else return;
    app_process();
}
