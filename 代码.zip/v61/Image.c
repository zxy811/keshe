#include "dsp_app.h"
unsigned char dbImage[IMAGEPIXELS],dbTargetImage[IMAGEPIXELS];
dsp_i16 gInputRow[IMAGEWIDTH],gOutputRow[IMAGEWIDTH];
dsp_i16 gSignalIn[FFT_N],gSignalOut[FFT_N];
dsp_i16 gFFTReal[FFT_N],gFFTImag[FFT_N],gFFTMag[FFT_N/2+1];
volatile unsigned int gBusy,gResultSeq,gMode,gCutoffIndex;
volatile unsigned int gLastKey,gFilterIndex,gStopped;
