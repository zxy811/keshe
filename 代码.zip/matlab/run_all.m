function run_all()
% On your LOCAL computer: cd to this matlab folder, then type run_all.
% No Python, Image Processing Toolbox, or Signal Processing Toolbox required.
% The virtual machine and CCS do not need MATLAB.
here=fileparts(mfilename('fullpath'));root=fileparts(here);
out=fullfile(root,'simulation_results');
if ~exist(out,'dir'),mkdir(out);end
if exist('OCTAVE_VERSION','builtin')
    runtime=['GNU Octave ' OCTAVE_VERSION];
else
    runtime=['MATLAB ' version];
end
fs=32000;N=256;taps=257;beta=5.65326;
m=-(taps-1)/2:(taps-1)/2;
win=besseli(0,beta*sqrt(max(0,1-(m/128).^2)))/besseli(0,beta);
banks=zeros(28,taps);names=cell(28,1);
for k=1:28
    if k<=10
        lo=k*1000;hi=0;h=(2*lo/fs)*sinc_local(2*lo/fs*m).*win;
        h=h/sum(h);names{k}=sprintf('LPF_%d',lo);
    else
        if k<=19,lo=(k-10)*1000;else,lo=(k-19)*1000;end
        hi=lo+1000;
        h=2*hi/fs*sinc_local(2*hi/fs*m)-2*lo/fs*sinc_local(2*lo/fs*m);
        if k<=19
            h=h.*win;h=h/sum(h.*cos(2*pi*((lo+hi)/2)/fs*m));
            names{k}=sprintf('BPF_%d_%d',lo,hi);
        else
            h=-h;h(129)=h(129)+1;h=h.*win;h=h/sum(h);
            names{k}=sprintf('BRF_%d_%d',lo,hi);
        end
    end
    q=max(-32768,min(32767,round(h*32768)));banks(k,:)=q;
    H=fft(q/32768,131072);H=H(1:65536);f=(0:65535)*fs/131072;
    fig=figure('Visible','off','Position',[100 100 1000 650]);
    subplot(2,1,1);plot(f/1000,20*log10(max(abs(H),1e-12)));grid on;
    ylim([-110 5]);xlim([0 16]);xlabel('Frequency (kHz)');ylabel('Magnitude (dB)');
    title([names{k} ' | 257-tap Q15 FIR'],'Interpreter','none');
    subplot(2,1,2);plot(f/1000,unwrap(angle(H))*180/pi);grid on;
    xlim([0 16]);xlabel('Frequency (kHz)');ylabel('Unwrapped phase (deg)');
    print(fig,fullfile(out,[names{k} '_bode.png']),'-dpng','-r140');close(fig);
end
delivered=csvread(fullfile(here,'coefficients_q15.csv'));
assert(isequal(banks,delivered),'Q15 coefficients differ from the DSP table.');
% Read the SAME fixed 80x80 bitmap embedded in ImageData.h.
A=double(imread(fullfile(root,'v61','sample.bmp')));
assert(isequal(size(A),[80 80]),'Expected the supplied grayscale 80x80 sample.bmp.');
Cinput=csvread(fullfile(here,'reference_c','input.csv'));
assert(isequal(A,Cinput),'BMP differs from the compiled C input.');
frames=cell(7,1);labels={'LPF 4 kHz','BPF 4-5 kHz','BRF 4-5 kHz','FFT DIT','FFT DIF','AM','DSB'};
indices=[4 14 23];
for j=1:3
    frames{j}=filter_picture(A,banks(indices(j),:));
end
row=[(A(41,:)-128)*128 zeros(1,176)];
X=fft(row)/N;XC=fft_fixed(row,0);XD=fft_fixed(row,1);
errC=max(abs(XC-X));errD=max(abs(XD-X));
assert(errC<6 && errD<6,'Image-row FFT error exceeds six integer counts.');
frames{4}=spectrum_picture(XC);frames{5}=spectrum_picture(XD);
carrier=repmat([32767 0 -32767 0],1,20);
message=A-128;
frames{6}=max(0,min(255,floor((64+fix(message/2)).*repmat(carrier,80,1)/32768)+128));
frames{7}=max(0,min(255,floor(message.*repmat(carrier,80,1)/32768)+128));
frame_error=zeros(7,1);
for j=1:7
    C=csvread(fullfile(here,'reference_c',sprintf('mode_%d.csv',j)));
    frame_error(j)=max(abs(C(:)-frames{j}(:)));
    assert(frame_error(j)==0,'Image output differs from the actual portable C output.');
    imwrite(uint8(frames{j}),fullfile(out,sprintf('key_%d.png',j)));
end
imwrite(uint8(A),fullfile(out,'original.png'));
CDIT=csvread(fullfile(here,'reference_c','fft_4.csv'));
CDIF=csvread(fullfile(here,'reference_c','fft_5.csv'));
assert(isequal([real(XC(:)) imag(XC(:))],CDIT),'DIT integer output mismatch.');
assert(isequal([real(XD(:)) imag(XD(:))],CDIF),'DIF integer output mismatch.');
fig=figure('Visible','off','Position',[100 100 1200 650]);
subplot(2,4,1);imagesc(A,[0 255]);axis image off;title('Fixed source');
for j=1:7
    subplot(2,4,j+1);imagesc(frames{j},[0 255]);axis image off;title(labels{j});
end
colormap(gray(256));print(fig,fullfile(out,'image_results.png'),'-dpng','-r160');close(fig);
% Representative magnitude AND phase plots for inclusion in the report.
fig=figure('Visible','off','Position',[100 100 1100 850]);
for j=1:3
    H=fft(banks(indices(j),:)/32768,32768);H=H(1:16384);f=(0:16383)*fs/32768;
    subplot(3,2,2*j-1);plot(f/1000,20*log10(max(abs(H),1e-12)));grid on;ylim([-100 3]);
    title(names{indices(j)},'Interpreter','none');xlabel('Frequency (kHz)');ylabel('Magnitude (dB)');
    subplot(3,2,2*j);plot(f/1000,unwrap(angle(H))*180/pi);grid on;
    xlabel('Frequency (kHz)');ylabel('Phase (deg)');
end
print(fig,fullfile(out,'bode_summary.png'),'-dpng','-r150');close(fig);
fig=figure('Visible','off','Position',[100 100 1000 650]);
subplot(2,1,1);plot(0:79,A(41,:)-128);grid on;xlabel('Image column');ylabel('Centered gray');
subplot(2,1,2);plot((0:128)/N,abs(X(1:129)),'k-');hold on;
plot((0:128)/N,abs(XC(1:129)),'r.');plot((0:128)/N,abs(XD(1:129)),'gx');grid on;
legend('Reference FFT/N','C DIT model','C DIF model');xlabel('Spatial frequency (cycles/pixel)');ylabel('Magnitude count');
print(fig,fullfile(out,'image_fft.png'),'-dpng','-r150');close(fig);
% Separate Hz-domain experiment: same fixed signal samples as the C tables.
n=0:N-1;
x=round(4500*(cos(2*pi*500*n/fs)+cos(2*pi*4000*n/fs)+cos(2*pi*9000*n/fs)+cos(2*pi*13000*n/fs)));
S=fft(x)/N;S1=fft_fixed(x,0);S2=fft_fixed(x,1);
fig=figure('Visible','off','Position',[100 100 1000 650]);
subplot(2,1,1);plot(n/fs*1000,x);grid on;xlabel('Time (ms)');ylabel('Input count');
subplot(2,1,2);stem((0:128)*fs/N/1000,abs(S(1:129)));hold on;
plot((0:128)*fs/N/1000,abs(S1(1:129)),'r.');plot((0:128)*fs/N/1000,abs(S2(1:129)),'gx');grid on;
xlabel('Frequency (kHz)');ylabel('FFT/N magnitude');
print(fig,fullfile(out,'signal_fft.png'),'-dpng','-r150');close(fig);
msg=round(12000*cos(2*pi*1000*n/fs));car=repmat([32767 0 -32767 0],1,64);
am=floor((16384+fix(msg/2)).*car/32768);dsb=floor(msg.*car/32768);
fig=figure('Visible','off','Position',[100 100 1000 750]);
for j=1:2
    if j==1,y=am;lab='AM';mode=6;else,y=dsb;lab='DSB';mode=7;end
    C=csvread(fullfile(here,'reference_c',sprintf('signal_%d.csv',mode)));
    assert(isequal(C(:,1),msg(:)) && isequal(C(:,2),y(:)),'Modulation differs from C output.');
    subplot(2,2,2*j-1);plot(n/fs*1000,y);title(lab);grid on;xlabel('Time (ms)');ylabel('Output count');
    Y=abs(fft(y)/N);
    subplot(2,2,2*j);stem((0:128)*fs/N/1000,Y(1:129));grid on;
    xlabel('Frequency (kHz)');ylabel('Magnitude count');
end
print(fig,fullfile(out,'modulation.png'),'-dpng','-r150');close(fig);
csvwrite(fullfile(out,'frame_errors.csv'),[(1:7).' frame_error]);
csvwrite(fullfile(out,'image_fft.csv'),[(0:N-1).' real(X(:)) imag(X(:)) real(XC(:)) imag(XC(:)) real(XD(:)) imag(XD(:))]);
save(fullfile(out,'simulation.mat'),'A','frames','banks','fs','X','XC','XD','am','dsb','-v7');
fid=fopen(fullfile(out,'RUN_COMPLETED.txt'),'w');
fprintf(fid,'Actual runtime: %s\n',runtime);
fprintf(fid,'Image: v61/sample.bmp (embedded in ImageData.h)\n');
fprintf(fid,'Coefficient comparison: all 7196 integers identical.\n');
fprintf(fid,'All seven image outputs identical to actual portable C outputs.\n');
fprintf(fid,'Image FFT errors: DIT %.9g; DIF %.9g integer counts.\n',errC,errD);
fprintf(fid,'Not a C55x hardware run; not a MATLAB run unless runtime above says MATLAB.\n');fclose(fid);
fprintf('Runtime: %s\nAll 7 image outputs match C exactly. Output: %s\n',runtime,out);
end

function B=filter_picture(A,h)
B=zeros(80,80);idx=-128:207;
while any(idx<0 | idx>=80)
    z=idx<0;idx(z)=-idx(z);z=idx>=80;idx(z)=158-idx(z);
end
for y=1:80
    padded=A(y,idx+1)-128;
    B(y,:)=max(0,min(255,floor(conv(padded,h,'valid')/32768)+128));
end
end

function B=spectrum_picture(X)
M=floor(abs(X(1:129)));top=max(1,max(M));B=10*ones(80,80);
for x=0:79
    first=floor(x*129/80);last=floor((x+1)*129/80)-1;
    height=floor(max(M(first+1:last+1))*79/top);
    B(80-height:80,x+1)=240;
end
end

function y=sinc_local(x)
y=ones(size(x));nz=(x~=0);y(nz)=sin(pi*x(nz))./(pi*x(nz));
end

function z=fft_fixed(x,dif)
N=256;z=complex(double(x),zeros(size(x)));w=round(32767*exp(-2i*pi*(0:127)/N));
if dif, spans=256./(2.^(0:7));else,z=bitreverse_local(z);spans=2.^(1:8);end
for span=spans
    half=span/2;
    for base=0:span:N-1
        for k=0:half-1
            i=base+k+1;j=i+half;idx=k*N/span;
            a=z(i);b=z(j);
            if dif
                z(i)=sat_complex(fix_complex((a+b)/2));d=fix_complex((a-b)/2);
                t=multiply_twiddle(d,w(idx+1),idx);z(j)=sat_complex(t);
            else
                t=multiply_twiddle(b,w(idx+1),idx);
                z(i)=sat_complex(fix_complex((a+t)/2));z(j)=sat_complex(fix_complex((a-t)/2));
            end
        end
    end
end
if dif,z=bitreverse_local(z);end
end

function y=multiply_twiddle(x,w,k)
if k==0,y=x;elseif k==64,y=complex(imag(x),-real(x));
else,y=complex(floor((real(x)*real(w)-imag(x)*imag(w))/32768),floor((real(x)*imag(w)+imag(x)*real(w))/32768));end
end

function y=fix_complex(x)
y=complex(fix(real(x)),fix(imag(x)));
end

function y=sat_complex(x)
y=complex(max(-32768,min(32767,real(x))),max(-32768,min(32767,imag(x))));
end

function y=bitreverse_local(x)
N=256;y=x;
for n=0:N-1
    b=n;r=0;
    for k=1:8,r=2*r+mod(b,2);b=floor(b/2);end
    y(r+1)=x(n+1);
end
end
